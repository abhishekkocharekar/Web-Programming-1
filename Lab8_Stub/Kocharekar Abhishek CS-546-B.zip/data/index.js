//Here you will require data files and export them as used in previous labs
module.exports = {
    users: require('./people')
  };