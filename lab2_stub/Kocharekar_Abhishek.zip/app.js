const arrayUtils = require("./arrayUtils");
const objectUtils = require("./objectUtils");
const stringUtils = require("./stringUtils");

try{
    console.log(arrayUtils.arrayStats([11, 54, 79, 5, -25, 54, 19, 11, 56, 100]));
    console.log(arrayUtils.arrayStats("banana"));
}catch(e){
    console.log("Error:", e);
}

try{
    console.log(arrayUtils.makeObjects([4, 1], [1, 2]));
    console.log(arrayUtils.makeObjects());
}catch(e){
    console.log("Error:", e);
}

const arr1 = [5, 7]; 
const arr2 = [20, 5]; 
const arr3 = [true, 5, 'Patrick']; 
const arr4 = ["CS-546", 'Patrick']; 
const arr5 = [67.7, 'Patrick', true]; 
const arr6 = [true, 5, 'Patrick']; 
const arr7 = [undefined, 5, 'Patrick']; 
const arr8 = [null, undefined, true];
const arr9 = ["2D case", ["foo", "bar"], "bye bye"]
const arr10= [["foo", "bar"], true, "String", 10]

try{
    console.log(arrayUtils.commonElements(arr9,arr6));
    console.log(arrayUtils.commonElements("test"));
}catch(e){
    console.log("Error:", e);
}

try{
    console.log(stringUtils.palindromes('Wow! Did you see that racecar go?')); 
    console.log(stringUtils.palindromes(["asdf"])); 
}catch(e){
    console.log("Error:", e);
}

try{
    console.log(stringUtils.replaceChar("     Daddy          "));
    console.log(stringUtils.replaceChar());
}catch(e){
    console.log("Error:", e);
}

try{
    console.log(stringUtils.charSwap("hello", "world"));
    console.log(stringUtils.charSwap("Patrick", ""));
}catch(e){
    console.log("Error:", e);
}

const first = {a: 2, b: 3};
const second = {a: 2, b: 4};
const third = {a: 2, b: 3};
const forth = {a: {sA: "Hello", sB: "There", sC: "Class"}, b: 7, c: true, d: "Test"}
const fifth  = {c: true, b: 7, d: "Test", a: {sB: "There", sC: "Class", sA: "Hello"}}

try{
    console.log(objectUtils.deepEquality(first, second));
    console.log(objectUtils.deepEquality("foo", "bar"));
}catch(e){
    console.log("Error:", e);
}

const first2 = {name: {first: "Patrick", last: "Hill"}, age: 46};
const second2 = {school: "Stevens", name: {first: "Patrick", last: "Hill"}};
const third2 = {a: 2, b: {c: true, d: false}};
const forth2 = {b: {c: true, d: false}, foo: "bar"};

try{
    console.log(objectUtils.commonKeysValues(first2, second2));
    console.log(objectUtils.commonKeysValues("foo", "bar"));
}catch(e){
    console.log("Error:", e);
}

try{
    console.log(objectUtils.calculateObject({ a: 3, b: 7, c: 5 },  n => n * 2));
    console.log(objectUtils.calculateObject({ a: 3, b: 7, c: 5 },  "n"));
}catch(e){
    console.log("Error:", e);
}