const movies = require('./movies');
const reviews = require('./reviews');

module.exports = {
    movies,
    reviews
}