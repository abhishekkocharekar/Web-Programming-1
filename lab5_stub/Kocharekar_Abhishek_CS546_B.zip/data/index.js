const pokemon = require('./pokemon');

module.exports = pokemon;